export class Medicine {

    id: number;
    drugName: string;
    stock: string;
}
